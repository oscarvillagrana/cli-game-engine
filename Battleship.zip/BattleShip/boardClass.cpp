// Board Class: The Board class has not been written yet.  If this class is well designed, then it should be easy to write the rest of the game.  


// You will be submitting a written description of your thoughts on the Board class. 
// The most important part of this is a list of member data, member functions, and constructors that the class would have, and your thoughts on how a program with a user interface would use them.  
// Your write up can consist of a few sentences and some bullet points.  
// There is no need to spend too much time on this.


// --variables
//   width
//   length
// --member functions
//   add ship
//   clear board

// I think each time a user picks a point they get a return view of the board and a lay out of where their shots have been
// I think that each time a user should see two boards, one with his ships and the oponents shots ot his boats and another with his hits and missed hits of the opponents boats